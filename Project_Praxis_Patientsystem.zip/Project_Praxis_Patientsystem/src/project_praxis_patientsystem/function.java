/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_praxis_patientsystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author jawoosh
 */
public class function {
    
    public static void saving(JTable tab, String f) {
    try{
    File file=new File(".\\src\\"+f);
if(!file.exists()){
file.createNewFile() ;
}
    
    FileWriter fw =new FileWriter(file.getAbsoluteFile()) ;
    BufferedWriter bw = new BufferedWriter(fw);
    
    for(int i = 0 ;i < tab.getRowCount();i++){
    for(int j = 0 ;j < tab.getColumnCount();j++){
        bw.write((String)tab.getModel().getValueAt(i , j)+"!@#");
    }
    bw.write("\n");
    }
    bw.close();
    fw.close();
    
    
    }catch(Exception ex){
        ex.printStackTrace();
    }
}
    
    
public static void loading(JTable tab, String f){

    String line;
BufferedReader reader;
    try{       
        reader = new BufferedReader(new FileReader(".\\src\\"+f));
        DefaultTableModel model=(DefaultTableModel) tab.getModel();
        while((line = reader.readLine()) != null) 
        {
           model.addRow(line.split("!@#")); 
        }
        reader.close();
     }
    catch(IOException e){
        JOptionPane.showMessageDialog(null, "Error");
e.printStackTrace();

    }
}
    
}
